<template>
  <div>
    <button @click="printme">
        print
    </button>
    <table class="invoiceWindow">
        <thead>
            <tr>
                <td>
                    <div class="header">
                         <div class="row p-5 " >
                <div class="col-md-4 col-up">
                    <span class="sp-up"></span>
                    <img width="80%" src="/img/transcrop.PNG" alt="logo"><br>
                    <small>House 68, Road 20 </small>
                    <small>Sector 11, Uttara, Dhaka 1230 </small><br>
                    <small>Bangladesh </small><br>
                    <small>Email: lifesciences@transcorp.com.bd  </small><br>
                    <p class="mt-4" style="font-weight:bold;background-color:#2A2F5F;font-size:10px;color:#D3E6EC;width:70%;margin:0;">CUSTOMER</p>
                    <!-- <i>{{invoice.customer}}</i><br>
                    <i>{{invoice.customerPhone}}</i><br>
                    <i>{{invoice.customerEmail}}</i> -->
                    <!-- <i>Please fill in</i> -->
                </div>
                <div class="col-md-4">
                    <img width="45%" src="/img/iso_img.PNG" alt="logo"><br>
                    <p class="mt-4" style="font-weight:bold;background-color:#2A2F5F;font-size:10px;color:grey;width:70%;margin:0">Ship To</p>
                    <!-- <i>{{invoice.shipTo}}</i> -->
                </div>
                <div class="col-md-4">
                     <img style="margin-top:50px" width="40%" src="/img/quatition.PNG" alt="logo"><br>
                     <!-- <small style="font-weight:bold">DATE:</small><span style="font-size:10px;background-color:#D3E6EC;padding:1px 24px">{{ today }}</span><br> -->
                     <!-- <small style="font-weight:bold">Delivery date:</small><span style="font-size:10px;background-color:#D3E6EC;padding:1px 24px">{{invoice.delivaryDate}}</span><br>
                     <small style="font-weight:bold">Quotation:</small><span style="font-size:10px;border:none;padding:1px;background-color:#D3E6EC;">{{invoice.quotationNumber}}</span> -->
                </div>
            </div>
                    </div>
                </td>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                      <div>LOREMLorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio id necessitatibus reiciendis veritatis perferendis, hic totam ut deserunt omnis eius, iusto consequatur voluptates porro autem sapiente. Perspiciatis doloremque officiis dignissimos ipsa aspernatur cum officia delectus eos, esse illo! Incidunt maxime perferendis impedit ad? Labore impedit fuga rerum, porro, culpa perspiciatis voluptas laudantium autem quae molestiae dolor non alias! Alias necessitatibus dignissimos, error, unde rerum iste possimus dolor numquam at tempora odio harum illo veritatis. Possimus aperiam libero repellendus facere! Consequuntur soluta sunt magni laboriosam veniam reprehenderit ipsam tempora dolores quod, accusantium molestiae velit, laudantium similique nisi quos tenetur, non assumenda placeat. Et commodi nam iure magni saepe vero nihil deleniti cupiditate, cum explicabo exercitationem animi natus consequatur ipsam in ipsa, aut iste ab omnis maiores. Assumenda rem in optio ex consequuntur similique qui, reiciendis non ducimus enim fugiat quod aut ab odio voluptate laudantium esse asperiores, repellat nobis vero ea ut laboriosam maiores. Sint quibusdam, ducimus nemo asperiores quas dolor delectus iusto suscipit praesentium quod? Sapiente error eos ipsum ducimus quod hic nihil quidem tempora voluptatem dolorum. Sunt, illum sapiente! Tempora tenetur pariatur non velit autem nesciunt suscipit hic, ratione, doloribus excepturi vel dignissimos itaque quo numquam neque ipsum reiciendis minus id aut ab ducimus architecto modi? Modi nihil placeat est facilis assumenda atque iste obcaecati debitis, velit itaque sint repellat totam numquam magnam expedita. Quod quas atque suscipit recusandae quidem sed quisquam? Nulla dolores ex porro doloremque iure eveniet et, rem voluptas, atque sit repellendus voluptatum dolore cum molestiae quo odio at. Maxime perspiciatis quam similique porro asperiores non accusantium neque amet quaerat sit aliquam cum magni, impedit officiis vel ad architecto quibusdam, alias illo nisi. Culpa nemo laboriosam, eligendi in a, ad eaque et magnam facere hic, adipisci non iste. Excepturi commodi iste nostrum! Tempore velit tenetur eveniet et autem nostrum laudantium! Impedit tempore laboriosam quisquam obcaecati fuga quo debitis perspiciatis possimus, voluptates sit placeat temporibus, consectetur eaque non in ratione sed cum explicabo, laborum repellendus corrupti hic mollitia! Quasi illum ducimus earum voluptas consectetur quam ea tempora reprehenderit, sint architecto dolor soluta porro corporis nisi illo dignissimos iusto eligendi nemo, qui, quod quae pariatur. Voluptatum exercitationem dicta molestias sunt architecto magni sit hic praesentium cum porro placeat quia labore, nobis nam excepturi at sequi dolore doloribus omnis unde voluptates perferendis! Minus assumenda nesciunt provident aspernatur ratione? Error, voluptas cumque vero repellendus consequuntur sunt provident similique ea! Nihil eaque voluptate a dolor soluta, at quaerat. At eveniet vero facere mollitia, ullam sed vitae. Numquam nemo facilis animi vitae. Soluta, nam unde. Labore, laboriosam nihil. Blanditiis excepturi culpa itaque eos aliquam ab impedit praesentium, accusantium, cupiditate ducimus inventore dolorum. Adipisci id rem asperiores architecto cumque ipsa possimus, a culpa nemo incidunt facere ut neque corporis laudantium nulla suscipit repellendus error praesentium inventore distinctio. Natus error ipsa suscipit dolor, laboriosam laborum vero consectetur, optio dignissimos ad, maiores voluptatum quos hic nostrum ratione maxime libero quis illum facere earum quisquam? Soluta nemo magnam accusantium qui aperiam saepe dignissimos nobis quidem sint optio architecto aliquam quae iure iusto, beatae molestiae libero deleniti voluptatibus incidunt sequi. Iusto ut a velit aut similique accusamus, maxime deserunt distinctio et temporibus unde natus autem. Laborum, quia magni voluptate dolore amet est facere a voluptatum necessitatibus maxime, commodi aut eos suscipit! Non possimus beatae ex officiis quibusdam doloremque rerum nesciunt quae ullam dolorum explicabo harum tempora vitae ipsum quia repellat quisquam nobis, ea natus dicta? Eum dolores deleniti ducimus ea voluptatibus tempora? Eveniet sequi esse nisi facere officiis quia dicta, suscipit, accusantium dolore natus harum beatae similique, mollitia odit sed autem quos necessitatibus doloremque modi voluptatem iste veritatis! Sunt, doloribus. Molestiae hic accusantium et perspiciatis dolorum, modi iusto laboriosam velit error voluptate, optio sit iste voluptatem? Iure, maxime reprehenderit repellendus tempora magnam nulla numquam odio quaerat laudantium sequi nostrum sit adipisci hic saepe, qui voluptate quod dolores nemo. Veritatis harum repellat quia consequatur facere vero incidunt fuga, alias fugiat expedita officia necessitatibus numquam quod laborum libero dolorum est amet earum saepe adipisci commodi nisi iusto quae. Reiciendis, debitis. Aspernatur in non asperiores et nostrum culpa, exercitationem architecto. Sint illum voluptatem voluptatibus ipsum iusto cum tempora ipsam nostrum? Nulla similique iure eaque laudantium, vero explicabo nobis eveniet? Nisi adipisci ratione, quia at aperiam minus libero architecto accusantium obcaecati voluptatibus praesentium sequi nesciunt amet est tempora, fugiat accusamus! Possimus similique itaque illum a assumenda architecto accusamus quaerat voluptas dolores laboriosam porro numquam sunt quia minima autem in debitis vero sed corporis, repudiandae animi odit molestias. Sunt, nemo? Deleniti, beatae fuga? Praesentium, asperiores perferendis. Perspiciatis inventore laborum reprehenderit odio earum possimus rerum velit mollitia tempore, quidem omnis assumenda dolorem minima ad corrupti fugiat blanditiis ducimus quam. Nam iusto quod recusandae ad vel. Quidem quas ratione molestiae placeat beatae. Ea soluta placeat repudiandae, esse tempora omnis magni quasi alias harum nesciunt! Nulla vero quam architecto commodi dolorum aliquid blanditiis sint voluptatibus optio ut eaque quibusdam odit ducimus enim, quod sequi pariatur! Quos assumenda quidem, nesciunt modi aperiam repudiandae! Quas, animi incidunt. Unde molestiae veritatis facilis maxime ratione voluptates, ducimus quisquam saepe, natus ad fugit quis consectetur facere et. Sit nesciunt alias doloremque a eius consequuntur aliquid vel aliquam, vero, soluta laudantium non sapiente enim atque obcaecati ullam ut officia et sunt accusamus. Cumque nulla fuga fugit consequatur tempore sed veniam dolorum voluptatum neque optio! Molestiae voluptas amet quos. Molestias dolorem facilis ex officiis laudantium atque laborum! Obcaecati inventore commodi libero eius, ut amet doloribus porro quasi, illo dolore tempora delectus! Ipsa recusandae illo ad quibusdam! Repellendus dicta voluptate esse odit porro voluptatibus vel doloremque quas eos sit, culpa saepe dignissimos, quo, est eaque ea rem inventore illum placeat quibusdam. Tenetur voluptas architecto, repellendus, doloribus numquam, veritatis aliquam vero est nostrum possimus adipisci molestiae et reprehenderit commodi voluptatum! Velit sint minus dolor consequatur autem porro hic animi natus assumenda ipsa nostrum quaerat at quia consequuntur excepturi eum asperiores commodi tenetur enim nemo expedita veritatis, itaque labore? Cupiditate illum labore, facilis blanditiis dolorum incidunt culpa obcaecati distinctio amet quis quam tempore ratione optio! Alias, odio doloribus error non veniam modi eligendi, hic vel quaerat delectus tempora, quisquam repudiandae fugiat. Totam fugiat vero expedita voluptas esse omnis rem cumque quas perferendis itaque ipsa velit sequi incidunt laboriosam ullam obcaecati dolorem doloribus in temporibus nulla illum nisi, repellendus numquam. Unde illo dolorum officiis tenetur doloremque corporis odit sapiente tempore quos iste ad perferendis rerum, repellendus blanditiis laboriosam facilis fugiat voluptatibus incidunt dolor autem ducimus quis. Ad obcaecati omnis explicabo repudiandae ex dicta exercitationem optio quae asperiores. Sunt exercitationem, ea, consequatur sed deserunt similique et alias fugiat pariatur sequi, corrupti quidem incidunt expedita. Consequatur dicta sapiente, optio voluptatem illo eligendi perspiciatis earum saepe minus impedit temporibus, dolores deserunt consequuntur. Expedita delectus in sequi est, tempore illo. Incidunt ipsa, iure laboriosam minus laudantium numquam, itaque est doloribus officiis quasi ducimus ipsum, similique architecto nostrum asperiores eaque! Explicabo at dolores, est odit quae nesciunt tenetur magnam ex! Esse, qui? Repudiandae in itaque tenetur quos maxime nobis laborum dolor explicabo pariatur enim autem ea voluptates facilis esse labore cumque reprehenderit ex, nam, nisi numquam velit harum. Fugit ipsa itaque adipisci vel fugiat voluptatem suscipit facilis asperiores maxime distinctio consequatur quibusdam assumenda deserunt repudiandae quidem odio, dolore exercitationem blanditiis praesentium commodi obcaecati iusto enim ullam. Necessitatibus repellendus eligendi nulla debitis, eveniet unde voluptatibus molestiae! Iure dolore perferendis beatae est tempore amet, pariatur nobis omnis voluptatibus cumque perspiciatis asperiores ipsam ad consequatur minima reprehenderit, quos dolorum. Minima id veniam, laboriosam facilis quis nam, corporis, numquam iusto esse praesentium tempora! Nisi illo perferendis amet, rem aliquid quidem autem sunt libero maiores quaerat voluptates voluptate quasi tempore alias ea! Non voluptatum magnam expedita porro, quod nam, minima et ipsam mollitia inventore repudiandae recusandae minus quo a rem! Rem odio perspiciatis accusamus iusto ullam laboriosam sed provident magni natus consequuntur quo dolorem, nobis corrupti, accusantium distinctio sapiente eaque aut. Nulla odit dolores alias rem itaque nisi sit possimus iure impedit culpa, hic, tenetur non optio incidunt at est dolor vel. Est aliquid provident inventore sequi aliquam suscipit beatae animi error facilis, sint illum blanditiis vitae nemo, tempore qui, ullam maiores quis in iure debitis. Excepturi minus est deserunt totam nihil officiis veritatis voluptatibus illo ipsam ea mollitia quidem ipsa ratione tempora nesciunt velit laborum incidunt, id voluptates in deleniti! Repudiandae eum rerum voluptatibus culpa, qui voluptatem neque nostrum molestiae aliquam alias eos sint vitae dicta, nisi corporis dolore adipisci esse laboriosam tenetur? Eveniet nobis repudiandae deserunt corrupti quas, totam cupiditate, officiis labore velit qui inventore odit incidunt quidem modi? Quis fuga, earum doloribus temporibus vero repellendus vitae sed facere placeat neque, exercitationem labore similique aliquam, alias quaerat veritatis doloremque omnis quidem natus rerum ducimus debitis! Iusto mollitia consequatur cumque sit nemo incidunt, odio obcaecati voluptate cupiditate delectus vero cum repellat molestias officiis odit fuga modi quia, earum in ipsa? Voluptatem pariatur temporibus repellat facilis. Soluta deserunt ullam assumenda, officiis similique, amet odio labore ut architecto et voluptas corporis odit corrupti quibusdam placeat error necessitatibus ad quidem. Sapiente nemo itaque veritatis voluptatibus, dignissimos suscipit debitis adipisci beatae nam! Quia, iusto perspiciatis autem magnam laborum minima voluptates at, dolor reprehenderit quos sunt officia? Inventore ab optio fuga aliquam odio ipsa! Quae unde voluptatum atque est aperiam laudantium sunt eos cum sed quisquam. Commodi, iure placeat iste qui corporis sint! Sit ipsa repellat, nulla est dolores nisi magni perferendis exercitationem reprehenderit dolor consequatur distinctio deleniti iste cum minus magnam nemo vero similique soluta numquam. Debitis repellat quae, ex harum expedita, voluptatibus quas excepturi voluptatum eaque distinctio dolorem dolor nulla? Similique, ea nisi. Enim, consequatur! Voluptates, ut nisi ea tempore temporibus eaque voluptas tempora blanditiis aut voluptate facere, nulla, quisquam repellat? Qui consequatur nemo, adipisci soluta natus sed. Similique architecto eius labore tenetur est minima a molestiae minus laborum ea magni cupiditate, enim sit quo eveniet perspiciatis facilis debitis mollitia doloribus dolore cumque obcaecati. Iusto dolor rerum eligendi at ex, aperiam quam animi ea sint exercitationem fugit harum aut a error, temporibus dolorum impedit praesentium assumenda quos culpa ullam veniam voluptates illo sed. Tempore reiciendis corrupti molestias vel deserunt. Adipisci laborum similique repellat vel eius quo perferendis fugit magnam placeat eaque, id repellendus voluptas nesciunt numquam ratione illum mollitia odio, itaque dolores quae doloremque iure sequi? Ipsam, repellendus facilis. Corporis totam sit expedita odit corrupti dignissimos ab laborum accusantium dolor dolores laudantium nihil nulla esse quidem, ullam tempora vel omnis magnam repellendus quos praesentium iure deserunt architecto amet. Quis, soluta natus provident quisquam et placeat cum doloribus explicabo eius illum, magni asperiores reiciendis perspiciatis voluptatibus sapiente laudantium expedita quod, iure nam repellat ad! Maxime assumenda cupiditate qui neque dicta et dolor veritatis dolorem distinctio aliquam aut, explicabo aperiam at perferendis, quibusdam voluptas quas quod porro. Quo, temporibus at dolore eveniet ad corporis earum dolor ea dignissimos officiis unde iure dolorem saepe doloribus ipsa a molestiae excepturi quaerat maxime nihil quisquam! Tenetur officia nostrum, sunt laudantium quibusdam odit, doloremque nobis impedit sapiente aut facere quae tempora. Ipsum mollitia illo adipisci alias molestiae aperiam pariatur exercitationem? Aspernatur fugiat expedita blanditiis aperiam exercitationem similique totam cumque molestiae beatae autem minima laboriosam molestias architecto fuga enim, commodi ipsum, quidem aut labore, ea dolore qui! Minima in ab molestiae unde explicabo fugiat quisquam, iste numquam sint ea sunt ullam quis sequi dignissimos commodi libero ex. Reprehenderit aperiam fuga aspernatur id laborum pariatur est ipsa? Voluptates, dicta necessitatibus eum dolor quo, accusantium molestiae sequi dolorem reprehenderit quae, sunt ratione vitae culpa quod delectus voluptas a! Dolor eveniet quaerat, perferendis harum iusto, optio iure distinctio adipisci architecto eligendi illum omnis rerum! Minima ipsam error, aliquam inventore impedit modi aspernatur ratione, provident dolore laudantium sunt voluptate quae nihil dolorum architecto fugiat sapiente atque illo. Sunt cumque ipsa qui vero ex aperiam non labore explicabo nulla, velit officiis dolore incidunt odio dolorem quae harum nihil eveniet omnis assumenda nesciunt excepturi porro cum veniam! Commodi facere, odio repudiandae ullam architecto iusto asperiores cumque error quod omnis, beatae quos, totam dolore optio corporis eum nesciunt. Ducimus assumenda animi nostrum rem minima quo voluptate culpa ipsam aspernatur, cupiditate soluta LOREM.</div>
                </td>
            </tr>
        </tbody>
        <tfoot>
            <tr>
                <td>
                       <div class="footer">The Footer</div>
                </td>
            </tr>
        </tfoot>
    </table>

  </div>
</template>
<script>
export default {
    methods: {
        printme(){
            window.print()
        }
    }
}
</script>
<style>
     @media print {
    .invoiceWindow {
        background-color: white;
        height: 100%;
        width: 100%;
        position: fixed;
        top: 0;
        left: 0;
        margin: 0;
        padding: 15px;
        font-size: 14px;
        line-height: 18px;
        color-adjust: exact; 
        -webkit-print-color-adjust: exact;
        /* print-color-adjust: exact; */
        -webkit-print-color-adjust: exact;
    }
    /* .invoiceWindow .header{
        position: sticky;
    } */
    /* .header, .header-space,
        .footer, .footer-space {
        height: 100px;
        }.header {
        position: fixed;
        top: 0;
        }.footer {
        position: fixed;
        bottom: 0;
} */
    
}
</style>